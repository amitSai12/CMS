package com.java.rms;

public enum Ordstatus {
	ACCEPTED,DENIED,PENDING
}
