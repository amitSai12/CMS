package com.java.ejb;

import java.util.List;

public interface CustomerDAO {

	String addCustomer(Customer customer);
	List<Customer> showCustomer();
}
