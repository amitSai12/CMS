package com.java.ejb;

import java.util.List;

public interface InsuranceDAO {
	
	List<InsuranceDetails> showInsurance();

}
